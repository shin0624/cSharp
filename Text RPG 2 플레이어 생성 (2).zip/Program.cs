﻿using System;

namespace Text_RPG_2_플레이어_생성
{
    class Program
    {
        static void Main(string[] args)
        {
            Player player = new Knight();
            Monster monster = new Ork();

            int damage = player.GetAttack();
            monster.OnDamaged(damage);
        }
    }
}
