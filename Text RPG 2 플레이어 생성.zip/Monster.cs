﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Text_RPG_2_플레이어_생성
{
    class Monster
    {
    }
}
